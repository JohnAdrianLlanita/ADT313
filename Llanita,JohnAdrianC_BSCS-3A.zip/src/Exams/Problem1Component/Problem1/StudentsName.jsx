import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import React from 'react';


function StudentsName(){




const StudentDetails = ({ studentName, course, section }) => {
  return (
    <div>
      <h2>Student Details</h2>
      <p><strong>Name:</strong> {studentName}</p>
      <p><strong>Course:</strong> {course}</p>
      <p><strong>Section:</strong> {section}</p>
    </div>
  );
};


}

export default StudentsName;