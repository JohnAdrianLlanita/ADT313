import React, { useReducer } from 'react';
import data from './problem8mock_data.json';


const initialState = {
  foods: data,
  selectedFood: null,
};


const actionTypes = {
  CREATE: 'CREATE',
  READ: 'READ',
  UPDATE: 'UPDATE',
  DELETE: 'DELETE',
  CLEAR: 'CLEAR',
};


function reducer(state, action) {
  switch (action.type) {
    case actionTypes.CREATE:
      return {
        ...state,
        foods: [...state.foods, action.payload],
      };
    case actionTypes.READ:
      return {
        ...state,
        selectedFood: action.payload,
      };
    case actionTypes.UPDATE:
      return {
        ...state,
        foods: state.foods.map(food =>
          food.food_name === action.payload.food_name ? action.payload : food
        ),
        selectedFood: null, 
      };
    case actionTypes.DELETE:
      return {
        ...state,
        foods: state.foods.filter(food => food.food_name !== action.payload),
        selectedFood: null,
      };
    case actionTypes.CLEAR:
      return {
        ...state,
        selectedFood: null,
      };
    default:
      return state;
  }
}

export default function Problem8() {
  const [state, dispatch] = useReducer(reducer, initialState);
  const { foods, selectedFood } = state;

  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    dispatch({
      type: actionTypes.READ,
      payload: { ...selectedFood, [name]: value },
    });
  };

  
  const handleSave = () => {
    if (selectedFood) {
      
      dispatch({ type: actionTypes.UPDATE, payload: selectedFood });
    } else {
      
      const newFood = {
        food_name: document.getElementById('food-name').value,
        price: parseFloat(document.getElementById('price').value),
        expiration_date: document.getElementById('expiration').value,
        calories: parseInt(document.getElementById('calories').value),
      };
      dispatch({ type: actionTypes.CREATE, payload: newFood });
    }
  };

  const handleClear = () => {
    dispatch({ type: actionTypes.CLEAR });
  };

  const handleEdit = (food) => {
    dispatch({ type: actionTypes.READ, payload: food });
  };

  const handleDelete = (foodName) => {
    dispatch({ type: actionTypes.DELETE, payload: foodName });
  };

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          Food Name:{' '}
          <input
            id="food-name"
            type="text"
            name="food_name"
            value={selectedFood?.food_name || ''}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Price:{' '}
          <input
            id="price"
            type="text"
            name="price"
            value={selectedFood?.price || ''}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Expiration Date:{' '}
          <input
            id="expiration"
            type="text"
            name="expiration_date"
            value={selectedFood?.expiration_date || ''}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Calories:{' '}
          <input
            id="calories"
            type="text"
            name="calories"
            value={selectedFood?.calories || ''}
            onChange={handleInputChange}
          />
        </div>

        <button type="button" onClick={handleSave}>
          {selectedFood ? 'Update' : 'Save'}
        </button>
        <button type="button" onClick={handleClear}>
          Clear
        </button>
      </div>
      <div className="table-container">
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>Food Name</th>
              <th>Price</th>
              <th>Expiration Date</th>
              <th>Calories</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {foods.map((food, index) => (
              <tr key={index}>
                <td>{food.food_name}</td>
                <td>{food.price}</td>
                <td>{food.expiration_date}</td>
                <td>{food.calories}</td>
                <td>
                  <button type="button" onClick={() => handleEdit(food)}>
                    Edit
                  </button>
                  <button type="button" onClick={() => handleDelete(food.food_name)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
