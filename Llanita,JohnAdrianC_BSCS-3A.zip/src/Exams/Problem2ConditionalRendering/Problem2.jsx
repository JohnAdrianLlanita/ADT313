import { useState } from 'react';

function Problem2() {
  // User data
  const user = {
    name: 'Hedy Lamarr',
    imageUrl: 'https://i.imgur.com/yXOvdOSs.jpg',
    imageSize: 90,
  };

  
  function Profile() {
    return (
      <>
        <h1>{user.name}</h1>
        <img
          className='avatar'
          src={user.imageUrl}
          alt={'Photo of ' + user.name}
          style={{
            width: user.imageSize,
            height: user.imageSize,
          }}
        />
      </>
    );
  }

  
  function InitialContent() {
    return <h1>User profile is hidden.</h1>;
  }

 
  const [isVisible, setIsVisible] = useState(false); 

  
  const toggleProfile = () => {
    setIsVisible((prevState) => !prevState); 
  };

  return (
    <>
      <div>
       
        {isVisible ? <Profile /> : <InitialContent />}

        
        <button type='button' onClick={toggleProfile}>
          {isVisible ? 'Hide Profile' : 'Show Profile'}
        </button>
      </div>
    </>
  );
}

export default Problem2;
