import { useEffect, useState } from 'react';
import Loading from './Problem5Components/Loading'; 

export default function Problem5() {
  const [isLoading, setIsLoading] = useState(true); 
  const [isTyping, setIsTyping] = useState(false); 
  const [lastActivityTime, setLastActivityTime] = useState(Date.now()); 
  const [idleTime, setIdleTime] = useState(0); 

 
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false); 
    }, 3000); 
    return () => clearTimeout(timer); 
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      const idleDuration = Date.now() - lastActivityTime; 
      setIdleTime(idleDuration);

    
      if (idleDuration > 5000) {
        setIsTyping(false);
      }
    }, 1000); 

    return () => clearInterval(interval); 
  }, [lastActivityTime]);

  
  const handleActivity = () => {
    setIsTyping(true); 
    setLastActivityTime(Date.now()); 
    setIdleTime(0); 
  };


  useEffect(() => {
    window.addEventListener('keydown', handleActivity);
    window.addEventListener('mousemove', handleActivity);

    return () => {
      window.removeEventListener('keydown', handleActivity);
      window.removeEventListener('mousemove', handleActivity);
    };
  }, []);

  return (
    <>
      {isLoading ? (
        <Loading />
      ) : (
        <>
          <div style={{ display: 'block' }}>
            Input: <input type="text" />
            <p>{isTyping ? 'User is typing...' : 'User is idle...'}</p>
            <p>Idle time: {Math.floor(idleTime / 1000)} seconds</p>
          </div>
        </>
      )}
    </>
  );
}
