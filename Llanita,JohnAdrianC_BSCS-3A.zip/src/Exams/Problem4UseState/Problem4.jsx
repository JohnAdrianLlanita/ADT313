import { useState } from 'react';

export default function Problem4() {
  const [name, setName] = useState('');
  const [yearLevel, setYearLevel] = useState('');
  const [course, setCourse] = useState('BSCS');

  const handleNameChange = (e) => {
    setName(e.target.value);
  };

  const handleYearLevelChange = (e) => {
    setYearLevel(e.target.value);
  };

  const handleCourseChange = (e) => {
    setCourse(e.target.value);
  };

  return (
    <>
      <div style={{ display: 'block' }}>
        <label>
          Name:
          <input
            type="text"
            value={name}
            onChange={handleNameChange}
          />
        </label>
      </div>

      <div style={{ display: 'block' }}>
        <p>Year Level:</p>
        <input
          type="radio"
          id="firstYear"
          name="yearlevel"
          value="First Year"
          checked={yearLevel === 'First Year'}
          onChange={handleYearLevelChange}
        />
        <label htmlFor="firstYear">First Year</label>
        <br />
        <input
          type="radio"
          id="secondYear"
          name="yearlevel"
          value="Second Year"
          checked={yearLevel === 'Second Year'}
          onChange={handleYearLevelChange}
        />
        <label htmlFor="secondYear">Second Year</label>
        <br />
        <input
          type="radio"
          id="thirdYear"
          name="yearlevel"
          value="Third Year"
          checked={yearLevel === 'Third Year'}
          onChange={handleYearLevelChange}
        />
        <label htmlFor="thirdYear">Third Year</label>
        <br />
        <input
          type="radio"
          id="fourthYear"
          name="yearlevel"
          value="Fourth Year"
          checked={yearLevel === 'Fourth Year'}
          onChange={handleYearLevelChange}
        />
        <label htmlFor="fourthYear">Fourth Year</label>
        <br />
        <input
          type="radio"
          id="fifthYear"
          name="yearlevel"
          value="Fifth Year"
          checked={yearLevel === 'Fifth Year'}
          onChange={handleYearLevelChange}
        />
        <label htmlFor="fifthYear">Fifth Year</label>
        <br />
        <input
          type="radio"
          id="irregular"
          name="yearlevel"
          value="Irregular"
          checked={yearLevel === 'Irregular'}
          onChange={handleYearLevelChange}
        />
        <label htmlFor="irregular">Irregular</label>
        <br />
      </div>

      <div style={{ display: 'block' }}>
        <label>
          Course:
          <select value={course} onChange={handleCourseChange}>
            <option value="BSCS">BSCS</option>
            <option value="BSIT">BSIT</option>
            <option value="BSCpE">BSCpE</option>
            <option value="ACT">ACT</option>
          </select>
        </label>
      </div>

      <div>
        <h3>Form Data</h3>
        <p>Name: {name}</p>
        <p>Year Level: {yearLevel}</p>
        <p>Course: {course}</p>
      </div>
    </>
  );
}
